import SwiftUI
internal import Combine

class HomeViewModel: ObservableObject {
    // @Published significa: "Quando questa variabile cambia, avvisa la View di ridisegnarsi"
    @Published var categories: [Category] = []
    
    // ci sarà una variabile dedicata a ciascun livello
    // (facendo così è più facile rendere le variabili accessibili alle view che implementano i livelli,
    // cioè giochi, lezioni ecc, che modificano la variabile quando sono completati)
    @Published var lessonCompleted: Bool = false
    //@Published var tapGameWon: Bool = false
    @Published var gameWon: Bool = true // usata dalle singole view giochi
    @Published var gameCompleted: Bool = false
    @Published var ideaCompleted: Bool = false
    
    init() {
        loadData()
    }
    
    
    // chiamata ogni volta che HomeView viene mostrata
    // si occupa di controllare se il livello corrente è stato superato
    // se sì, lo segna come completato e sblocca il successivo
    // work in progress
    func refreshLevelsStatus() {
        for cIndex in categories.indices {
            for lIndex in categories[cIndex].levels.indices {
                
                //var level = categories[cIndex].levels[lIndex] // smette di funzionare ???
                //var nextLevel = categories[cIndex].levels[lIndex + 1] // dà errore
                
                if(categories[cIndex].levels[lIndex].status == .current){
                    
                    if(categories[cIndex].levels[lIndex].type == "Lesson" && self.lessonCompleted){ // questo poi sarà uno switch(level.type)
                        categories[cIndex].levels[lIndex].status = .completed
                        categories[cIndex].levels[lIndex + 1].status = .current // sarebbe nextLevel
                    }
                    
                    if(categories[cIndex].levels[lIndex].type == "Game" && self.gameCompleted){ // questo poi sarà uno switch(level.type)
                        categories[cIndex].levels[lIndex].status = .completed
                        categories[cIndex].levels[lIndex + 1].status = .current // sarebbe nextLevel
                    }
                    
                    if(categories[cIndex].levels[lIndex].type == "Idea" && self.ideaCompleted){ // questo poi sarà uno switch(level.type)
                        categories[cIndex].levels[lIndex].status = .completed
                        categories[cIndex + 1].levels[0].status = .current // sarebbe nextLevel
                    }
                    
                }
            }
        }
    }
    
    func loadData() {
        // Qui simuliamo il caricamento dei dati
        self.categories = [
            Category(
                name: "Unit 1: Recycling",
                description: "Paper, plastic, and glass",
                //color: Color(red: 0.3, green: 0.7, blue: 0.35),
                color: myYellow,
                guideContent: "The YELLOW bin is for plastic...",
                imageName: "recycleImage",
                levels: [
                    Level(number: 1, type: "Lesson", status: .current),
                    Level(number: 2, type: "Game", status: .locked),
                    Level(number: 3, type: "Idea", status: .locked)
                ]
            ),
            Category(
                name: "Unit 2: Reuse",
                description: "Donate and repair objects",
                //color: Color(red: 0.2, green: 0.5, blue: 0.9),
                color: myLightBlue,
                guideContent: "Before throwing it away...",
                imageName: "reuseImage",
                levels: [
                    Level(number: 4, type: "Lesson2", status: .locked), // temp
                    Level(number: 5, type: "Game2", status: .locked),
                    Level(number: 6, type: "Idea2", status: .locked)
                ]
            ),
            Category(
                name: "Unit 3: Sharing",
                description: "Local sharing economy",
                //color: Color(red: 0.6, green: 0.3, blue: 0.8),
                color: myGreen,
                guideContent: "Use car sharing...",
                imageName: "shareImage",
                levels: [
                    Level(number: 7, type: "Lesson3", status: .locked),
                    Level(number: 8, type: "Game3", status: .locked),
                    Level(number: 9, type: "Idea3", status: .locked)
                ]
            )
        ]
    }
}
