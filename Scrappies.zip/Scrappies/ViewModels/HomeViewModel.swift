import SwiftUI
internal import Combine

class HomeViewModel: ObservableObject {
    @Published var categories: [Category] = []
    
    @Published var lessonCompleted: Bool = false
    @Published var gameWon: Bool = true
    @Published var gameCompleted: Bool = false
    @Published var ideaCompleted: Bool = false
    
    init() {
        loadData()
    }
    
    func refreshLevelsStatus() {
        for cIndex in categories.indices {
            for lIndex in categories[cIndex].levels.indices {
                
                if(categories[cIndex].levels[lIndex].status == .current){
                    
                    if(categories[cIndex].levels[lIndex].type == "Lesson" && self.lessonCompleted){
                        categories[cIndex].levels[lIndex].status = .completed
                        categories[cIndex].levels[lIndex + 1].status = .current
                    }
                    
                    if(categories[cIndex].levels[lIndex].type == "Game" && self.gameCompleted){
                        categories[cIndex].levels[lIndex].status = .completed
                        categories[cIndex].levels[lIndex + 1].status = .current
                    }
                    
                    if(categories[cIndex].levels[lIndex].type == "Idea" && self.ideaCompleted){
                        categories[cIndex].levels[lIndex].status = .completed
                        categories[cIndex + 1].levels[0].status = .current
                    }
                    
                }
            }
        }
    }
    
    func loadData() {
        self.categories = [
            Category(
                name: "Unit 1: Recycling",
                description: "Paper, plastic, and glass",
                color: myYellow,
                guideContent: "The YELLOW bin is for plastic...",
                imageName: "recycleImage",
                levels: [
                    Level(number: 1, type: "Lesson", status: .current),
                    Level(number: 2, type: "Game", status: .locked),
                    Level(number: 3, type: "Idea", status: .locked)
                ]
            ),
            Category(
                name: "Unit 2: Reuse",
                description: "Donate and repair objects",
                color: myLightBlue,
                guideContent: "Before throwing it away...",
                imageName: "reuseImage",
                levels: [
                    Level(number: 4, type: "Lesson2", status: .locked),
                    Level(number: 5, type: "Game2", status: .locked),
                    Level(number: 6, type: "Idea2", status: .locked)
                ]
            ),
            Category(
                name: "Unit 3: Sharing",
                description: "Local sharing economy",
                color: myGreen,
                guideContent: "Use car sharing...",
                imageName: "shareImage",
                levels: [
                    Level(number: 7, type: "Lesson3", status: .locked),
                    Level(number: 8, type: "Game3", status: .locked),
                    Level(number: 9, type: "Idea3", status: .locked)
                ]
            )
        ]
    }
}
