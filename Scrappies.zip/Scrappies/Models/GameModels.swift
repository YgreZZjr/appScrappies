import SwiftUI

enum Tab {
    case home
    case achievement
    case settings
}

enum LevelStatus {
    case completed, current, locked
}

struct Level: Identifiable {
    let id = UUID()
    let number: Int
    var type: String
    var status: LevelStatus
}

struct Category: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let color: Color
    let guideContent: String
    let imageName: String
    var levels: [Level]
}

enum TrashType: CaseIterable {
    case plastic
    case paper
    case general

    var color: Color {
        switch self {
        case .plastic: return .yellow
        case .paper: return .blue
        case .general: return .gray
        }
    }

    var icon: String {
        switch self {
        case .plastic: return "plasticBin"
        case .paper: return "paperBin"
        case .general: return "glassBin"
        }
    }

    var title: String {
        switch self {
        case .plastic: return "Plastic"
        case .paper: return "Paper"
        case .general: return "Glass"
        }
    }
}

struct TrashItem: Identifiable {
    let id = UUID()
    let name: String
    let image: String
    let type: TrashType
    var offset: CGSize = .zero
    var isCorrect: Bool = false
}

struct BinView: View {
    let type: TrashType

    var body: some View {
        VStack {
            ZStack {
                Image(type.icon)
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.white)
            }

            Text(type.title)
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundColor(.gray)
        }
        .frame(width: 100, height: 120)
        .background(Color.white.opacity(0.01))
    }
}
