//
//  ColorPalette.swift
//  tempProject
//
//  Created by Foundation 15 on 28/01/26.
//

import SwiftUI

let myYellow = Color(red: 0.973, green: 0.812, blue: 0.376)
let myLightBlue = Color(red: 0.651, green: 0.859, blue: 0.945)
let myGreen = Color(red: 0.714, green: 0.843, blue: 0.427)

// 0.714 0.843 0.427
