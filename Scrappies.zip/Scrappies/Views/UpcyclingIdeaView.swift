import SwiftUI

struct UpcyclingIdeaView: View {

    @EnvironmentObject var viewModel: HomeViewModel
    @State var backToMainView: Bool = false

    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack(alignment: .center) {

                    HStack {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("UPCYCLING IDEA!")
                            .bold()
                            .font(.title2)
                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 50)

                    VStack {

                        HStack(alignment: .top) {

                            Text("You could turn a...")
                                .padding(.horizontal, 20)
                                .font(.title3)

                            Spacer()

                        }

                        Text("")
                        Text("")
                        Text("")

                        HStack(alignment: .top) {

                            Spacer()

                            Text("Water bottle")
                                .padding(.horizontal, 20)
                                .font(.largeTitle)
                                .bold()
                                .italic()

                        }
                    }

                    Text("")
                    Text("")
                    Text("")

                    HStack(alignment: .top) {

                        Text("Into a...")
                            .padding(.horizontal, 20)
                            .font(.title3)

                        Spacer()

                    }

                    Text("")
                    Text("")
                    Text("")

                    HStack(alignment: .top) {

                        Spacer()

                        Text("Vase!")
                            .padding(.horizontal, 20)
                            .font(.largeTitle)
                            .bold()
                            .italic()

                    }

                    Image("bottle")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 320)
                        .offset(y: -50)

                    Text("Did you do it? Don't lie!")
                        .bold()
                        .font(.title3)
                        .offset(y: -80)
                    
                    Button {

                        backToMainView = true
                        viewModel.ideaCompleted = true

                    } label: {
                        Text("I did it!")
                            .bold()
                            .font(.title2)
                            .padding(.horizontal, 40)
                            .padding(.vertical, 20)
                            .foregroundStyle(Color.black)
                            .background(myYellow)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .shadow(radius: 4)
                            
                    }
                    .offset(y: -60)
                    
                    Spacer()

                }

            }
            .navigationDestination(isPresented: $backToMainView) {
                MainView()
                    .navigationBarBackButtonHidden(true)
            }
        }
    }
}

#Preview {
    UpcyclingIdeaView()
        .environmentObject(HomeViewModel())
}
