import SwiftUI

struct MainLessonView: View {

    @EnvironmentObject var viewModel: HomeViewModel
    
    @Environment(\.dismiss) var dismiss
    
    @State var currentPage: Int = 0
    
    @State var textOnButton: String = "Continue"
    
    @State var quitView: Bool = false
    
    @State var isEnabled: Bool = false

    var numberOfViews: Int = 4
    
    init() {
        UIPageControl.appearance().currentPageIndicatorTintColor = UIColor(
            myYellow
        )
        UIPageControl.appearance().pageIndicatorTintColor = .white
    }

    var body: some View {

        NavigationStack {

            ZStack {

                myYellow.ignoresSafeArea()

                TabView(selection: $currentPage) {

                    Lesson1View()
                        .tag(0)
                    Lesson2View()
                        .tag(1)
                    Lesson3View()
                        .tag(2)
                    LessonEndView()
                        .tag(3)

                }
                .tabViewStyle(.page)
                .tint(myYellow)
                .indexViewStyle(.page(backgroundDisplayMode: .always))
                .ignoresSafeArea()

                Button {
                    
                    buttonPressed()

                } label: {
                    Text(textOnButton)
                        .bold()
                        .font(.title2)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 20)
                        .foregroundStyle(Color.black)
                        .background(isEnabled ? myYellow : Color.gray)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(radius: 4)
                }
                .offset(y: 300)
                .disabled(!isEnabled)
            }
            .navigationDestination(isPresented: $quitView){
                MainView()
                    .navigationBarBackButtonHidden(true)
            }
        }
        .onAppear {
            quitView = false
            currentPage = 0
            textOnButton = "Continue"
            cooldown()
        }
    }
    
    func buttonPressed() {
        
        isEnabled = false
        
        if currentPage < numberOfViews - 1 {
            currentPage += 1
        } else {
            quitView = true
        }

        if currentPage == numberOfViews - 1 {
            textOnButton = "Done!"
            viewModel.lessonCompleted = true
        } else {
            textOnButton = "Continue"
        }
        
        cooldown()
        
    }
    
    func cooldown(){
        
        var countdown: Int = 3
        
        Task{
            while(countdown > 0 && textOnButton != "Done!"){
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                countdown -= 1
            }
            withAnimation(.easeInOut){
                isEnabled = true
            }
        }
        
    }
    
}

#Preview {
    MainLessonView()
        .environmentObject(HomeViewModel())
}
