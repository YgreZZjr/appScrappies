//
//  temp.swift
//  tempProject
//
//  Created by Foundation 15 on 29/01/26.
//


// This view hosts the TabView that manages all the other ones in order

import SwiftUI

struct MainLessonView: View {

    @EnvironmentObject var viewModel: HomeViewModel
    
    @Environment(\.dismiss) var dismiss
    
    @State var currentPage: Int = 0 // used to select the view currently displayed
    
    @State var textOnButton: String = "Continue" // will change on the last view
    
    @State var quitView: Bool = false // used by the X on top to quit
    
    @State var isEnabled: Bool = false // used for button press cooldown

    var numberOfViews: Int = 4 // EDIT with the amount of views you want to have
    
    // this colors the dots on the bottom of the screen
    init() {
        // Makes the selected dot appear yellow
        UIPageControl.appearance().currentPageIndicatorTintColor = UIColor(
            myYellow
        )
        // Makes the unselected dots appear white
        UIPageControl.appearance().pageIndicatorTintColor = .white
    }

    var body: some View {

        NavigationStack {

            ZStack {

                myYellow.ignoresSafeArea() // needed for top background

                // list of views in the tab with corresponding index (currentPage, 0->3)
                TabView(selection: $currentPage) {

                    Lesson1View()
                        .tag(0)
                    Lesson2View()
                        .tag(1)
                    Lesson3View()
                        .tag(2)
                    LessonEndView()
                        .tag(3)

                }
                .tabViewStyle(.page)
                .tint(myYellow)
                .indexViewStyle(.page(backgroundDisplayMode: .always))
                .ignoresSafeArea()

                // "continue" button
                Button {
                    
                    buttonPressed()

                } label: {
                    Text(textOnButton)
                        .bold()
                        .font(.title2)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 20)
                        .foregroundStyle(Color.black)
                        .background(isEnabled ? myYellow : Color.gray)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(radius: 4)
                }
                .offset(y: 300)
                .disabled(!isEnabled) // cooldown to avoid spam pressing
            }
            .navigationDestination(isPresented: $quitView){
                MainView() // tells the view where to go
                    .navigationBarBackButtonHidden(true)
            }
        }
        .onAppear {
            quitView = false
            currentPage = 0
            textOnButton = "Continue"
            cooldown()
        }
    }
    
    func buttonPressed() {
        
        isEnabled = false
        
        // goes to next page if we are not at the end
        if currentPage < numberOfViews - 1 {
            currentPage += 1
        } else {
            //dismiss() <- alternativa corretta ma non sblocca il livello successivo
            quitView = true // if we go beyond the last view, we quit and go back home
        }

        // changes the text on the button on the last view
        if currentPage == numberOfViews - 1 {
            textOnButton = "Done!"
            viewModel.lessonCompleted = true
        } else {
            textOnButton = "Continue"
        }
        
        cooldown()
        
    }
    
    func cooldown(){
        
        var countdown: Int = 3 // num of seconds of wait
        
        Task{
            while(countdown > 0 && textOnButton != "Done!"){
                try? await Task.sleep(nanoseconds: 1_000_000_000) // waits for 1 sec
                countdown -= 1
            }
            withAnimation(.easeInOut){
                isEnabled = true
            }
        }
        
    }
    
}

#Preview {
    MainLessonView()
        .environmentObject(HomeViewModel())
}
