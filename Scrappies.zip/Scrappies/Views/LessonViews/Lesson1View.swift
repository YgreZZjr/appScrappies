
import SwiftUI

struct Lesson1View: View {
    
    @State private var backToMainView: Bool = false
    
    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack {

                    HStack {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("LESSON 1: ")
                            .bold()
                            .font(.title2)

                        Text("RECYCLING")
                            .font(.title2)
                            .foregroundStyle(Color.gray)
                            .bold()

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 60)

                    Image("whatIsRecycling")
                        .resizable()
                        .scaledToFit()

                    Text("What is Recycling?")
                        .bold()
                        .font(.title)
                        .padding()

                    Text("Using old things\n to make\n new things!")
                        .padding()
                        .font(.title2)
                        .bold()
                        .multilineTextAlignment(.center)

                    Spacer()
                }
                .navigationDestination(isPresented: $backToMainView){
                    MainView()
                        .navigationBarBackButtonHidden(true)
                }
            }
        }
        .onAppear {
            backToMainView = false
        }

    }
}

#Preview {
    Lesson1View()
}
