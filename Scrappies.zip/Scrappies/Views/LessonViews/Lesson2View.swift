//
//  Lesson2View.swift
//  tempProject
//
//  Created by Foundation 15 on 29/01/26.
//

import SwiftUI

struct Lesson2View: View {

    @State private var backToMainView: Bool = false

    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack {

                    HStack {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("LESSON: ")
                            .bold()
                            .font(.title2)

                        Text("RECYCLING")
                            .font(.title2)
                            .foregroundStyle(Color.gray)
                            .bold()

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 60)

                    //Rectangle()
                    //    .frame(width: 350, height: 200)
                    //    .padding()

                    Image("whatCanWeRecycle")
                        .resizable()
                        .scaledToFit()

                    Text("What Can We Recycle?")
                        .bold()
                        .font(.title)
                        .padding()

                    Text("Plastic!\n Paper!\n Glass!\n Metal!\n")
                        .padding()
                        .font(.title2)
                        .bold()
                        .multilineTextAlignment(.center)

                    Spacer()

                }
                .navigationDestination(isPresented: $backToMainView) {
                    MainView()
                        .navigationBarBackButtonHidden(true)
                }
            }
        }
        .onAppear {
            backToMainView = false
        }

    }
}

#Preview {
    Lesson2View()
}
