
import SwiftUI

struct LessonEndView: View {
    var body: some View {

        ZStack {
            myYellow.ignoresSafeArea()
            
            VStack {
                
                Text("You're a planet hero!⭐️")
                    .bold()
                    .font(.largeTitle)
                
                Image("planetHero")
                    .resizable()
                    .scaledToFit()
                
            }
        }
    }
}

#Preview {
    LessonEndView()
}
