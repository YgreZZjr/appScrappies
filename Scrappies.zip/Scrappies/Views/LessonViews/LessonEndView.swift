//
//  LessonEnd.swift
//  tempProject
//
//  Created by Foundation 15 on 29/01/26.
//

import SwiftUI

struct LessonEndView: View {
    var body: some View {

        ZStack {
            myYellow.ignoresSafeArea()
            
            VStack {
                
                Text("You're a planet hero!⭐️")
                    .bold()
                    .font(.largeTitle)
                
                Image("planetHero")
                    .resizable()
                    .scaledToFit()
                
            }
        }
    }
}

#Preview {
    LessonEndView()
}
