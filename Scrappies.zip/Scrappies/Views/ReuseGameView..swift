import SwiftUI

struct ReuseRecipe: Identifiable {
    let id = UUID()
    let baseName: String
    let baseIcon: String
    
    let ingredientName: String
    let ingredientIcon: String
    
    let resultName: String
    let resultIcon: String
    let color: Color
    
    var isMatched: Bool = false
}

struct ReuseGameView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @State private var recipes: [ReuseRecipe] = [
        ReuseRecipe(
            baseName: "Lattina", baseIcon: "🥫",
            ingredientName: "Fiori", ingredientIcon: "🌸",
            resultName: "Vaso", resultIcon: "🪴",
            color: .orange
        ),
        ReuseRecipe(
            baseName: "Pneumatico", baseIcon: "🛞",
            ingredientName: "Corda", ingredientIcon: "🪢",
            resultName: "Altalena", resultIcon: "🎠",
            color: .blue
        ),
        ReuseRecipe(
            baseName: "Vecchia T-Shirt", baseIcon: "👕",
            ingredientName: "Forbici", ingredientIcon: "✂️",
            resultName: "Stracci", resultIcon: "🧽",
            color: .purple
        )
    ]
    
    @State private var showWinMessage = false
    @State private var dragOffsets: [UUID: CGSize] = [:]
    @State private var targetFrames: [UUID: CGRect] = [:]
    
    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            
            VStack {
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.largeTitle).foregroundColor(.gray.opacity(0.5))
                    }
                    Spacer()
                    Text("Crea nuovi oggetti!")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundColor(.blue)
                    Spacer()
                    Image(systemName: "xmark.circle.fill").hidden()
                }
                .padding()
                
                Spacer()
                
                HStack(spacing: 40) {
                    
                    VStack(spacing: 30) {
                        ForEach(recipes) { recipe in
                            if !recipe.isMatched {
                                DraggableIngredient(
                                    icon: recipe.ingredientIcon,
                                    color: recipe.color,
                                    offset: dragOffsets[recipe.id] ?? .zero
                                )
                                .gesture(
                                    DragGesture(coordinateSpace: .named("ReuseSpace"))
                                        .onChanged { gesture in
                                            dragOffsets[recipe.id] = gesture.translation
                                        }
                                        .onEnded { gesture in
                                            checkMatch(for: recipe, dropLocation: gesture.location)
                                        }
                                )
                                .zIndex(dragOffsets[recipe.id] == .zero ? 0 : 100)
                            } else {
                                Circle().fill(Color.clear).frame(width: 80, height: 80)
                            }
                        }
                    }
                    
                    VStack(spacing: 50) {
                        ForEach(recipes) { recipe in
                            Image(systemName: "arrow.right")
                                .font(.title)
                                .foregroundColor(.gray.opacity(0.3))
                                .frame(height: 80)
                        }
                    }
                    
                    VStack(spacing: 30) {
                        ForEach(recipes) { recipe in
                            TargetBaseItem(recipe: recipe)
                                .background(
                                    GeometryReader { geo in
                                        Color.clear.onAppear {
                                            targetFrames[recipe.id] = geo.frame(in: .named("ReuseSpace"))
                                        }
                                    }
                                )
                        }
                    }
                }
                .padding()
                
                Spacer()
                
                Text("Trascina l'ingrediente sull'oggetto vecchio per trasformarlo!")
                    .font(.caption)
                    .foregroundColor(.gray)
                    .padding(.bottom, 30)
            }
            .coordinateSpace(name: "ReuseSpace")
            
            if showWinMessage {
                Color.black.opacity(0.4).ignoresSafeArea()
                VStack(spacing: 20) {
                    Text("✨")
                        .font(.system(size: 80))
                    Text("Tutto Riusato!")
                        .font(.system(size: 30, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                    Button("Continua") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .padding().background(Color.white).cornerRadius(20).foregroundColor(.blue)
                }
                .padding(40)
                .transition(.scale)
            }
        }
    }
    
    func checkMatch(for recipe: ReuseRecipe, dropLocation: CGPoint) {
        guard let targetFrame = targetFrames[recipe.id] else {
            returnItem(id: recipe.id)
            return
        }
        
        if targetFrame.contains(dropLocation) {
            withAnimation(.spring()) {
                if let index = recipes.firstIndex(where: { $0.id == recipe.id }) {
                    recipes[index].isMatched = true
                    dragOffsets[recipe.id] = .zero
                }
            }
            
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
            
            checkForWin()
            
        } else {
            returnItem(id: recipe.id)
            
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
        }
    }
    
    func returnItem(id: UUID) {
        withAnimation(.spring()) {
            dragOffsets[id] = .zero
        }
    }
    
    func checkForWin() {
        if recipes.allSatisfy({ $0.isMatched }) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation { showWinMessage = true }
            }
        }
    }
}

struct DraggableIngredient: View {
    let icon: String
    let color: Color
    let offset: CGSize
    
    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(0.2))
                .frame(width: 80, height: 80)
                .overlay(Circle().stroke(color, lineWidth: 2))
            
            Text(icon)
                .font(.system(size: 40))
        }
        .offset(offset)
        .shadow(color: color.opacity(0.3), radius: offset == .zero ? 0 : 10, x: 0, y: 5)
        .scaleEffect(offset == .zero ? 1.0 : 1.1)
    }
}

struct TargetBaseItem: View {
    let recipe: ReuseRecipe
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(recipe.isMatched ? Color.green.opacity(0.2) : Color.gray.opacity(0.1))
                .frame(width: 100, height: 100)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(recipe.isMatched ? Color.green : Color.gray.opacity(0.3), lineWidth: 2)
                )
            
            if recipe.isMatched {
                VStack {
                    Text(recipe.resultIcon).font(.system(size: 40))
                        .transition(.scale.combined(with: .opacity))
                    Text(recipe.resultName)
                        .font(.caption).bold().foregroundColor(.green)
                }
            } else {
                VStack {
                    Text(recipe.baseIcon).font(.system(size: 40))
                    Text(recipe.baseName)
                        .font(.caption).foregroundColor(.gray)
                }
            }
        }
        .animation(.spring(), value: recipe.isMatched)
    }
}

struct ReuseGameView_Previews: PreviewProvider {
    static var previews: some View {
        ReuseGameView()
    }
}
