import SwiftUI

struct GameItem: Identifiable {
    let id = UUID()
    let name: String
    let isCorrect: Bool
}

struct Game2View: View {

    @EnvironmentObject var viewModel: HomeViewModel

    let myYellow = Color(red: 0.973, green: 0.812, blue: 0.376)

    @State private var selected: [UUID: Bool] = [:]
    @State private var tappedWrong = false

    let items: [GameItem] = [
        GameItem(name: "metalCan2", isCorrect: true),
        GameItem(name: "glassBottle", isCorrect: true),
        GameItem(name: "paper", isCorrect: true),
        GameItem(name: "banana", isCorrect: false),
        GameItem(name: "teddyBear", isCorrect: false),
    ]

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]

    var allTapped: Bool {
        let correctIDs = items.filter { $0.isCorrect }.map { $0.id }
        return correctIDs.allSatisfy { selected[$0] == true }
    }

    var body: some View {
        VStack(spacing: 0) {

            ZStack {
                myYellow
                    .ignoresSafeArea(edges: .top)

                Text("Challenge")
                    .font(.title2)
                    .bold()
                    .padding(.top, 12)
            }
            .frame(height: 90)

            Text("Tap the items that can be recycled ♻️")
                .font(.title)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
                .padding(.top, 28)

            Spacer().frame(height: 40)

            LazyHStack {
                gameCell(items[0])
                gameCell(items[1])
                gameCell(items[3])
            }
            LazyHStack {
                gameCell(items[2])
                gameCell(items[4])
            }
            .padding(.bottom, 250)

            if tappedWrong {
                Text("")
                    .font(.title)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                    .padding(.top, 18)
            }

            Spacer()
        }
        .background(Color(.systemGroupedBackground))
        .onAppear {
            viewModel.gameWon = false
        }
    }

    func gameCell(_ item: GameItem) -> some View {

        let wasTapped = selected[item.id] != nil
        let correct = item.isCorrect

        return ZStack(alignment: .bottomTrailing) {

            Image(item.name)
                .resizable()
                .scaledToFit()
                .frame(width: 110, height: 110)
                .padding(2)
                .background(Color.white)
                .cornerRadius(18)
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(
                            wasTapped
                                ? (correct ? Color.green : Color.red)
                                : Color.clear,
                            lineWidth: 5
                        )
                )
                .onTapGesture {
                    if selected[item.id] == nil {
                        selected[item.id] = correct
                        if !correct {
                            tappedWrong = true
                        }
                    }
                }

            if wasTapped {
                if correct {
                    indicatorCircle()
                } else {
                    indicatorSquare()
                }
            }
        }
    }

    func checkForWin() {
        if allTapped {
            viewModel.gameWon = true
        }
    }

    func indicatorCircle() -> some View {
        return ZStack {
            Circle()
                .fill(Color.green)
                .frame(width: 28, height: 28)

            Image(systemName: "checkmark")
                .foregroundColor(.white)
                .bold()
        }
        .offset(x: 6, y: 6)
        .onAppear {
            checkForWin()
        }
    }

    func indicatorSquare() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7)
                .fill(Color.red)
                .frame(width: 28, height: 28)

            Image(systemName: "xmark")
                .foregroundColor(.white)
                .bold()
        }
        .offset(x: 6, y: 6)
    }
}

#Preview {
    Game2View()
        .environmentObject(HomeViewModel())
}
