//
//  Game2View.swift
//  tempProject
//
//  Created by Foundation 15 on 03/02/26.
//

import SwiftUI

struct GameItem: Identifiable {
    let id = UUID()
    let name: String
    let isCorrect: Bool
}

struct Game2View: View {

    @EnvironmentObject var viewModel: HomeViewModel

    let myYellow = Color(red: 0.973, green: 0.812, blue: 0.376)

    @State private var selected: [UUID: Bool] = [:]
    @State private var tappedWrong = false  // ✅ новое

    let items: [GameItem] = [
        GameItem(name: "metalCan2", isCorrect: true),
        GameItem(name: "glassBottle", isCorrect: true),
        GameItem(name: "paper", isCorrect: true),
        GameItem(name: "banana", isCorrect: false),
        GameItem(name: "teddyBear", isCorrect: false),
    ]

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]

    // Continue после всех правильных
    var allTapped: Bool {
        let correctIDs = items.filter { $0.isCorrect }.map { $0.id }
        return correctIDs.allSatisfy { selected[$0] == true }
    }

    var body: some View {
        VStack(spacing: 0) {

            // HEADER
            ZStack {
                myYellow
                    .ignoresSafeArea(edges: .top)

                Text("Challenge")
                    .font(.title2)
                    .bold()
                    .padding(.top, 12)
            }
            .frame(height: 90)

            // INSTRUCTION
            Text("Tap the items that can be recycled ♻️")
                .font(.title)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
                .padding(.top, 28)

            Spacer().frame(height: 40)

            // GRID
            /*LazyVGrid(columns: columns, spacing: 28) {
                ForEach(items) { item in
                    gameCell(item)
                }
            }
            .padding(.horizontal, 24)*/

            LazyHStack {
                gameCell(items[0])
                gameCell(items[1])
                gameCell(items[3])
            }
            LazyHStack {
                gameCell(items[2])
                gameCell(items[4])
            }
            .padding(.bottom, 250)

            // ❌ сообщение об ошибке
            if tappedWrong {
                Text("")
                    .font(.title)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                    .padding(.top, 18)
            }

            Spacer()

            // CONTINUE BUTTON
            /*if allTapped {
                Button(action: {
                    print("Continue tapped")
                }) {
                    Text("Continue")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.black)
                        .padding(.vertical, 14)
                        .padding(.horizontal, 60)
                        .background(myYellow)
                        .cornerRadius(22)
                }
                .padding(.bottom, 30)
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .animation(.easeOut, value: allTapped)
            }*/
        }
        .background(Color(.systemGroupedBackground))
        .onAppear {
            viewModel.gameWon = false
        }
    }

    // CELL
    func gameCell(_ item: GameItem) -> some View {

        let wasTapped = selected[item.id] != nil
        let correct = item.isCorrect

        return ZStack(alignment: .bottomTrailing) {

            Image(item.name)
                .resizable()
                .scaledToFit()
                .frame(width: 110, height: 110)
                .padding(2)
                .background(Color.white)
                .cornerRadius(18)
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(
                            wasTapped
                                ? (correct ? Color.green : Color.red)
                                : Color.clear,
                            lineWidth: 5
                        )
                )
                .onTapGesture {
                    if selected[item.id] == nil {
                        selected[item.id] = correct
                        if !correct {
                            tappedWrong = true  // ✅ фиксируем ошибочный клик
                        }
                    }
                }

            // INDICATORS
            if wasTapped {
                if correct {
                    indicatorCircle()
                } else {
                    indicatorSquare()
                }
            }
        }
    }

    func checkForWin() {
        if allTapped {
            viewModel.gameWon = true
        }
    }

    // GREEN CHECK
    func indicatorCircle() -> some View {
        return ZStack {
            Circle()
                .fill(Color.green)
                .frame(width: 28, height: 28)

            Image(systemName: "checkmark")
                .foregroundColor(.white)
                .bold()
        }
        .offset(x: 6, y: 6)
        .onAppear {
            checkForWin()
        }
    }
    

    // RED CROSS
    func indicatorSquare() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7)
                .fill(Color.red)
                .frame(width: 28, height: 28)

            Image(systemName: "xmark")
                .foregroundColor(.white)
                .bold()
        }
        .offset(x: 6, y: 6)
    }
}

#Preview {
    Game2View()
        .environmentObject(HomeViewModel())
}
