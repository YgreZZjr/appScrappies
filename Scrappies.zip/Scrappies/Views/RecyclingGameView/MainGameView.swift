 
import SwiftUI

struct MainGameView: View {
    
    @EnvironmentObject var viewModel: HomeViewModel
    
    @State var currentPage: Int = 0
    
    @State var textOnButton: String = "Continue"
    @State var quitView: Bool = false
    @State var isEnabled: Bool = false
    var numberOfViews: Int = 6
    init() {
        UIPageControl.appearance().currentPageIndicatorTintColor = UIColor(
            myYellow
        )
        UIPageControl.appearance().pageIndicatorTintColor = .white
    }
    
    
    var body: some View {
        
        NavigationStack {
            
            ZStack {
                
                myYellow.ignoresSafeArea()
                
                TabView(selection: $currentPage) {
                    
                    Game1View()
                        .tag(0)
                    Game3View()
                        .tag(1)
                    Game4View()
                        .tag(2)
                    Game5View()
                        .tag(3)
                    GameEndView()
                        .tag(4)
                    
                }
                .tabViewStyle(.page)
                .tint(myYellow)
                .indexViewStyle(.page(backgroundDisplayMode: .always))
                .ignoresSafeArea()
                
                
                Button {
                    
                    buttonPressed()
                    
                } label: {
                    Text(textOnButton)
                        .bold()
                        .font(.title2)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 20)
                        .foregroundStyle(Color.black)
                        .background(viewModel.gameWon ? myYellow : Color.gray)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(radius: 4)
                }
                .offset(y: 300)
                .disabled(!viewModel.gameWon) // cooldown to avoid spam pressing
            }
            .navigationDestination(isPresented: $quitView) {
                MainView()
                    .navigationBarBackButtonHidden(true)
            }
        }
        .onAppear {
            quitView = false
            currentPage = 0
            textOnButton = "Continue"
        }
    }
    
    func buttonPressed() {
        
        if currentPage < numberOfViews - 1 {
            currentPage += 1
        } else {
            quitView = true
            
            if currentPage == numberOfViews - 1 {
                textOnButton = "Done!"
                viewModel.lessonCompleted = true
            } else {
                textOnButton = "Continue"
            }
            
            
        }
        
    }
    
    #Preview {
        MainGameView()
            .environmentObject(HomeViewModel())
    }
}
