//
//  Game2View.swift
//  tempProject
//
//  Created by Foundation 15 on 02/02/26.
//

import SwiftUI

struct oldGame2View: View {
    
    @State private var backToMainView: Bool = false
    
    @EnvironmentObject var viewModel: HomeViewModel
    
    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack {

                    HStack() {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("CHALLENGE")
                            .font(.title2)
                            //.foregroundStyle(Color.gray)
                            .bold()

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 60)

                    

                    Spacer()
                }
                .navigationDestination(isPresented: $backToMainView){
                    MainView()
                        .navigationBarBackButtonHidden(true)
                }
            }
        }
        .onAppear {
            backToMainView = false
            //viewModel.gameWon = false // riattiva dopo
        }

    }
}

#Preview {
    oldGame2View()
        .environmentObject(HomeViewModel())
}

