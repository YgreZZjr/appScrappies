
import SwiftUI

struct GameEndView: View {
    var body: some View {

        ZStack {
            myYellow.ignoresSafeArea()
            
            VStack() {
                
                Text("You did it!\nYou're a planet hero!⭐️")
                    .bold()
                    .font(.largeTitle)
                    .multilineTextAlignment(.center)
                
                Image("planetHero2")
                    .resizable()
                    .scaledToFit()
                
            }
        }
    }
}

#Preview {
    GameEndView()
}
