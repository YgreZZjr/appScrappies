//
//  GameEndView.swift
//  tempProject
//
//  Created by Foundation 15 on 02/02/26.
//

import SwiftUI

struct GameEndView: View {
    var body: some View {

        ZStack {
            myYellow.ignoresSafeArea()
            
            VStack() {
                
                Text("You did it!\nYou're a planet hero!⭐️")
                    .bold()
                    .font(.largeTitle)
                    .multilineTextAlignment(.center)
                
                Image("planetHero2")
                    .resizable()
                    .scaledToFit()
                
            }
        }
    }
}

#Preview {
    GameEndView()
}
