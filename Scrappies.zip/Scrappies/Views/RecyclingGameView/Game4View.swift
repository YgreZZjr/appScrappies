//
//  Game4View.swift
//  tempProject
//
//  Created by Foundation 15 on 02/02/26.
//

import SwiftUI

// --- 2. VISTA GIOCO ---

struct Game4View: View {
    @Environment(\.presentationMode) var presentationMode
    
    @EnvironmentObject var viewModel: HomeViewModel
    

    // OGGETTI DEL GIOCO
    @State private var items: [TrashItem] = [
        
        //TrashItem(name: "Giornale", image: "paper", type: .paper),
        //TrashItem(name: "Bottiglia", image: "🥤", type: .plastic),
        TrashItem(name: "Mela", image: "glassBottle", type: .general)
    ]

    //@State private var gameWon = false

    @State private var backToMainView: Bool = false

    // Per salvare dove sono i bidoni sullo schermo
    @State private var binFrames: [TrashType: CGRect] = [:]

    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack {
                    // HEADER
                    HStack {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("CHALLENGE")
                            .font(.title2)
                            //.foregroundStyle(Color.gray)
                            .bold()

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 60)

                    Text("Drag the item\n to the right bin!")
                        .bold()
                        .font(.title2)

                    // --- AREA RIFIUTI (DRAGGABLE) ---
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.gray.opacity(0.1))
                            .frame(height: 140)
                            .padding()

                        HStack(spacing: 30) {
                            ForEach($items.indices, id: \.self) { index in
                                // Mostriamo l'oggetto solo se non è stato ancora indovinato
                                if !items[index].isCorrect {
                                    Image(items[index].image)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 40)
                                        //.font(.system(size: 20))
                                        .shadow(radius: 5)
                                        .offset(items[index].offset)
                                        // GESTURE DRAG
                                        .gesture(
                                            DragGesture(
                                                coordinateSpace: .named(
                                                    "GameSpace"
                                                )
                                            )
                                            .onChanged { gesture in
                                                items[index].offset =
                                                    gesture.translation
                                            }
                                            .onEnded { gesture in
                                                checkDrop(
                                                    at: index,
                                                    dropLocation: gesture
                                                        .location
                                                )
                                            }
                                        )
                                        // ZIndex serve per far passare l'oggetto SOPRA gli altri mentre trascini
                                        .zIndex(
                                            items[index].offset == .zero ? 0 : 1
                                        )
                                }
                            }
                        }
                    }
                    .padding(.bottom, 100)
                    .navigationDestination(isPresented: $backToMainView) {
                        MainView()
                            .navigationBarBackButtonHidden(true)
                    }
                    .onAppear {
                        viewModel.gameWon = false
                    }

                    // --- AREA BIDONI (TARGET) ---
                    HStack(spacing: 15) {
                        ForEach(TrashType.allCases, id: \.self) { type in
                            BinView(type: type)
                                // Salva la posizione di questo bidone
                                .background(
                                    GeometryReader { geo in
                                        Color.clear
                                            .onAppear {
                                                // Salviamo il rettangolo (frame) del bidone nello spazio globale
                                                binFrames[type] = geo.frame(
                                                    in: .named("GameSpace")
                                                )
                                            }
                                    }
                                )
                        }
                    }
                    .padding()

                    Spacer()

                }
                // Definizione dello Spazio Coordinate Globale
                .coordinateSpace(name: "GameSpace")

                // --- SCHERMATA VITTORIA ---
                /*if showWinMessage {
                    Color.black.opacity(0.4).ignoresSafeArea()
                
                    VStack(spacing: 20) {
                        Image(systemName: "star.circle.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.yellow)
                            .background(Circle().fill(Color.white))
                
                        Text("Livello Completato!")
                            .font(
                                .system(
                                    size: 28,
                                    weight: .heavy,
                                    design: .rounded
                                )
                            )
                            .foregroundColor(.white)
                
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Text("Continua")
                                .font(.headline)
                                .foregroundColor(.green)
                                .padding()
                                .frame(width: 200)
                                .background(Color.white)
                                .cornerRadius(20)
                        }
                    }
                    .padding(40)
                    .transition(.scale)
                }*/
            }
        }
    }

    // --- LOGICA DI CONTROLLO ---

    func checkDrop(at index: Int, dropLocation: CGPoint) {
        let item = items[index]

        // 1. Troviamo se il dito è finito dentro uno dei bidoni
        // Cerchiamo un bidone il cui rettangolo (frame) contiene il punto di rilascio
        if let targetBinType = binFrames.first(where: {
            $0.value.contains(dropLocation)
        })?.key {

            // 2. Controlliamo se il tipo è giusto
            if targetBinType == item.type {
                // SUCCESSO!
                withAnimation(.spring()) {
                    items[index].isCorrect = true
                    items[index].offset = .zero  // Resettiamo offset (ma tanto scompare)
                }
                checkForWin()
            } else {
                // ERRORE: Bidone sbagliato
                itemReturnBack(index: index)
            }
        } else {
            // ERRORE: Rilasciato fuori dai bidoni
            itemReturnBack(index: index)
        }
    }

    func itemReturnBack(index: Int) {
        // Vibrazione di errore
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.error)

        // Animazione molla per tornare indietro
        withAnimation(.interpolatingSpring(stiffness: 120, damping: 10)) {
            items[index].offset = .zero
        }
    }

    func checkForWin() {
        // Se tutti gli elementi sono corretti
        if items.allSatisfy({ $0.isCorrect }) {
            // Aspetta un attimo e mostra la vittoria
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation {
                    viewModel.gameWon = true
                }
            }
        }
    }
}

// --- VISTA SINGOLO BIDONE ---

#Preview {
    Game4View()
        .environmentObject(HomeViewModel())
}
