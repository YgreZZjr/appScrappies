import SwiftUI

struct Game1View: View {
    
    @State private var backToMainView: Bool = false
    
    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack {

                    HStack() {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("CHALLENGE")
                            .font(.title2)
                            //.foregroundStyle(Color.gray)
                            .bold()

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 60)
                    
                    Spacer()
                    VStack{
                        
                        ZStack {
                            
                            Image("textBubble")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 120)
                                .shadow(radius: 4)
                            
                            Text("Let's recycle together!")
                                .font(.title3)
                                .padding(.bottom, 20)
                            
                        }
                        
                        Image("recyclingTogether")
                            .resizable()
                            .scaledToFit()
                        
                    }
                    .padding(.bottom, 80)
                    Spacer()
                    
                }
                .navigationDestination(isPresented: $backToMainView){
                    MainView()
                        .navigationBarBackButtonHidden(true)
                }
            }
        }
        .onAppear {
            backToMainView = false
        }

    }
}

#Preview {
    Game1View()
}

