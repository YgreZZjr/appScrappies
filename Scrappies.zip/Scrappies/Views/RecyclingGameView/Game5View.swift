import SwiftUI

struct Game5View: View {
    @Environment(\.presentationMode) var presentationMode

    @EnvironmentObject var viewModel: HomeViewModel
    
    @State private var items: [TrashItem] = [
        TrashItem(name: "Bottiglia", image: "metalCan2", type: .plastic),
    ]

    @State private var backToMainView: Bool = false

    @State private var binFrames: [TrashType: CGRect] = [:]

    var body: some View {

        NavigationStack {

            ZStack {

                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {
                    myYellow.ignoresSafeArea()
                        .frame(height: 100)

                    Spacer()
                }

                VStack {
                    HStack {

                        Button {
                            backToMainView = true
                        } label: {
                            Image(systemName: "xmark")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(Color.black)
                        }

                        Text("CHALLENGE")
                            .font(.title2)
                            .bold()

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 60)

                    Text("Drag the item\n to the right bin!")
                        .bold()
                        .font(.title2)

                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.gray.opacity(0.1))
                            .frame(height: 140)
                            .padding()

                        HStack(spacing: 30) {
                            ForEach($items.indices, id: \.self) { index in
                                if !items[index].isCorrect {
                                    Image(items[index].image)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 60)
                                        .shadow(radius: 5)
                                        .offset(items[index].offset)
                                        .gesture(
                                            DragGesture(
                                                coordinateSpace: .named(
                                                    "GameSpace"
                                                )
                                            )
                                            .onChanged { gesture in
                                                items[index].offset =
                                                    gesture.translation
                                            }
                                            .onEnded { gesture in
                                                checkDrop(
                                                    at: index,
                                                    dropLocation: gesture
                                                        .location
                                                )
                                            }
                                        )
                                        .zIndex(
                                            items[index].offset == .zero ? 0 : 1
                                        )
                                }
                            }
                        }
                    }
                    .padding(.bottom, 100)
                    .navigationDestination(isPresented: $backToMainView) {
                        MainView()
                            .navigationBarBackButtonHidden(true)
                    }
                    .onAppear {
                        viewModel.gameWon = false
                    }

                    HStack(spacing: 15) {
                        ForEach(TrashType.allCases, id: \.self) { type in
                            BinView(type: type)
                                .background(
                                    GeometryReader { geo in
                                        Color.clear
                                            .onAppear {
                                                binFrames[type] = geo.frame(
                                                    in: .named("GameSpace")
                                                )
                                            }
                                    }
                                )
                        }
                    }
                    .padding()

                    Spacer()

                }
                .coordinateSpace(name: "GameSpace")
            }
        }
    }

    func checkDrop(at index: Int, dropLocation: CGPoint) {
        let item = items[index]

        if let targetBinType = binFrames.first(where: {
            $0.value.contains(dropLocation)
        })?.key {

            if targetBinType == item.type {
                withAnimation(.spring()) {
                    items[index].isCorrect = true
                    items[index].offset = .zero
                }
                checkForWin()
            } else {
                itemReturnBack(index: index)
            }
        } else {
            itemReturnBack(index: index)
        }
    }

    func itemReturnBack(index: Int) {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.error)

        withAnimation(.interpolatingSpring(stiffness: 120, damping: 10)) {
            items[index].offset = .zero
        }
    }

    func checkForWin() {
        if items.allSatisfy({ $0.isCorrect }) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation {
                    viewModel.gameWon = true
                    viewModel.gameCompleted = true
                }
            }
        }
    }
}

#Preview {
    Game5View()
        .environmentObject(HomeViewModel())
}
