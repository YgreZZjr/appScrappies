import SwiftUI

struct MainView: View {

    var body: some View {

        TabView {

            HomeView()
                .tabItem {
                    Label("Play!", systemImage: "house.fill")
                }

            AchievementView()
                .tabItem {
                    Label("Achievements", systemImage: "rosette")
                }
            
        }
        .tint(myYellow)

    }
}

#Preview {
    MainView()
        .environmentObject(HomeViewModel())
}
