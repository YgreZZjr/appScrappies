import SwiftUI

struct GameButtonStyle: ButtonStyle {
    let color: Color
    let status: LevelStatus
    
    func makeBody(configuration: Configuration) -> some View {
        ZStack {
            Circle()
                .fill(backgroundColor)
                .frame(width: 75, height: 75)
                .offset(y: 6)
            
            Circle()
                .fill(foregroundColor)
                .frame(width: 75, height: 75)
                .offset(y: configuration.isPressed ? 6 : 0)
            
            content
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(.white)
                .offset(y: configuration.isPressed ? 6 : 0)
        }
        .animation(.easeInOut(duration: 0.1), value: configuration.isPressed)
        .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
        .opacity(status == .locked ? 0.6 : 1.0)
    }
    
    var foregroundColor: Color {
        switch status {
        case .completed: return myYellow
        case .current: return color
        case .locked: return .gray
        }
    }
    
    var backgroundColor: Color {
        switch status {
        case .completed: return .orange
        case .current: return color.opacity(0.6)
        case .locked: return .gray.opacity(0.5)
        }
    }
    
    @ViewBuilder var content: some View {
        switch status {
        case .completed: Image(systemName: "checkmark")
        case .current: Image(systemName: "star.fill")
        case .locked: Image(systemName: "lock.fill").foregroundColor(.white.opacity(0.5))
        }
    }
}
