import SwiftUI

struct CategoryHeader: View {
    let category: Category
    let isTop: Bool
    
    var body: some View {
        ZStack {
            // Sfondo colorato
            category.color
            
            // Contenuto
            HStack {
                Text(category.name)
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundColor(.white)
                    .shadow(color: .black.opacity(0.2), radius: 2, x: 1, y: 1)
                    .multilineTextAlignment(.leading) // Allinea a sinistra se va a capo
                    .padding(.leading, 20) // Un po' di margine dal bordo sinistro
                
                Spacer() // Spinge il testo a sinistra
            }
            // LOGICA DI CENTRATURA VERTICALE:
            // Se è l'header in alto (isTop), aggiungiamo padding sopra per evitare la 'notch' (tacca).
            // Lo ZStack centrerà automaticamente il testo nello spazio rimanente.
            .padding(.top, isTop ? 50 : 0)
        }
        .frame(height: isTop ? 140 : 100)
    }
}
