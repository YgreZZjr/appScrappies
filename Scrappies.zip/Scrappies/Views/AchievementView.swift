import SwiftUI

struct Achievement: Identifiable {
    let id = UUID()
    let title: String
    let subtitle: String
    let imageName: String
}

struct AchievementView: View {
    
    @EnvironmentObject var viewModel: HomeViewModel
    
    let sandColor = Color(red: 0.73, green: 0.63, blue: 0.345)
    let myYellow = Color(red: 0.973, green: 0.812, blue: 0.376)
    
    @State var userName: String = "Enter your name!"
    @State private var showEditName = false
    @State private var newName: String = ""
    
    @State private var profileImageName: String = "dva"
    @State private var showPickPhoto = false
    
    let profileChoices = ["odin","dva","tri","cetiri","pyat","sest"]
    
    let tempAchievements: [Achievement] = [
        Achievement(title: "Planet Protector", subtitle: "You protect the planet", imageName: "planetprotector"),
        Achievement(title: "Eco Hero1", subtitle: "You help nature every day", imageName: "ecohero"),
        Achievement(title: "Eco Hero3", subtitle: "You help nature every day", imageName: "ecohero"),
        Achievement(title: "Eco Hero2", subtitle: "You help nature every day", imageName: "ecohero"),
        Achievement(title: "Eco Hero4", subtitle: "You help nature every day", imageName: "ecohero"),
        Achievement(title: "Add more", subtitle: "asdasd asdddaaa", imageName: "addmore"),
        Achievement(title: "Add more2", subtitle: "asdasd asdddaaa", imageName: "addmore")
    ]
    
    @State var achievements: [Achievement] = [
        Achievement(title: "Your achievements will be shown here", subtitle: "Start playing!", imageName: "character")
    ]

    func updateAchievements(){
        
        if(viewModel.lessonCompleted){
            
            if(achievements[0].title == "Your achievements will be shown here"){
                achievements.remove(at: 0)
            }
            
            achievements.insert(
                Achievement(title: "Recycling Erudite", subtitle: "You know everything about recycling!", imageName: "ecohero"), at: 0
            )
        }
        
        if(viewModel.gameCompleted){
            achievements.insert(
                Achievement(title: "Pro Player", subtitle: "That's how you do it!", imageName: "addmore"), at: 0
            )
        }
            
        if(viewModel.ideaCompleted){
            achievements.insert(
                Achievement(title: "Creative", subtitle: "Use your imagination!", imageName: "planetprotector"), at: 0
            )
        }
        
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                
                VStack(spacing: 16) {
                    
                    VStack(spacing: 28) {
                        
                        ZStack(alignment: .bottomTrailing) {
                            
                            Image(profileImageName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 250, height: 250)
                                .clipShape(Circle())
                            
                            Button {
                                showPickPhoto = true
                            } label: {
                                Image(systemName: "camera.fill")
                                    .font(.system(size: 18, weight: .medium))
                                    .foregroundColor(.black)
                                    .padding(10)
                                    .background(
                                        Circle()
                                            .fill(myYellow)
                                    )
                            }
                            .offset(x: -10, y: -10)
                        }

                        HStack(spacing: 8) {
                            Text(userName)
                                .font(.title)
                                .fontWeight(.medium)
                            
                            Button {
                                newName = userName
                                showEditName = true
                            } label: {
                                Image(systemName: "pencil")
                                    .font(.system(size: 18, weight: .medium))
                                    .foregroundColor(.black)
                                    .padding(8)
                                    .background(
                                        Circle()
                                            .fill(myYellow)
                                    )
                            }
                        }
                    }
                    
                    ZStack {
                        myYellow
                        
                        Text("My Achievements")
                            .font(.title2)
                            .fontWeight(.semibold)
                    }
                    .frame(height: 70)
                    .cornerRadius(16)
                    .padding(.horizontal)
                    
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(achievements) { achievement in
                                AchievementRow(achievement: achievement)
                            }
                        }
                        .padding(.horizontal)
                    }

                    Spacer()
                }
                
                if showEditName {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .onTapGesture {
                            showEditName = false
                        }
                    
                    VStack(spacing: 20) {
                        Text("Add new name")
                            .font(.headline)
                        
                        TextField("Enter new name", text: $newName)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                        
                        Button {
                            if !newName.trimmingCharacters(in: .whitespaces).isEmpty {
                                userName = newName
                            }
                            showEditName = false
                        } label: {
                            Text("Save")
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(myYellow)
                                .cornerRadius(12)
                                .foregroundColor(.black)
                        }
                    }
                    .padding()
                    .frame(width: 300)
                    .background(Color(.systemGray5))
                    .cornerRadius(20)
                    .onTapGesture { }
                }
                
                if showPickPhoto {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .onTapGesture {
                            showPickPhoto = false
                        }
                    
                    VStack(spacing: 20) {
                        
                        Text("pick new")
                            .font(.headline)
                        
                        LazyVGrid(
                            columns: [
                                GridItem(.flexible()),
                                GridItem(.flexible()),
                                GridItem(.flexible())
                            ],
                            spacing: 16
                        ) {
                            ForEach(profileChoices, id: \.self) { imageName in
                                Image(imageName)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle()
                                            .stroke(profileImageName == imageName ? Color.blue : .clear, lineWidth: 3)
                                    )
                                    .onTapGesture {
                                        profileImageName = imageName
                                        showPickPhoto = false
                                    }
                            }
                        }
                    }
                    .padding()
                    .frame(width: 320)
                    .background(Color(.systemGray5))
                    .cornerRadius(20)
                    .onTapGesture { }
                }
            }
            .navigationBarHidden(true)
            .onAppear{
                updateAchievements()
            }
        }
    }
}

struct AchievementRow: View {
    let achievement: Achievement
    
    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            
            Image(achievement.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 66, height: 66)
                .clipShape(Circle())
            
            VStack(alignment: .leading, spacing: 6) {
                Text(achievement.title)
                    .font(.headline)
                
                Text(achievement.subtitle)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

#Preview {
    AchievementView()
        .environmentObject(HomeViewModel())
}
