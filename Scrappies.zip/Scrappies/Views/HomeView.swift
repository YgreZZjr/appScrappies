import SwiftUI

struct HomeView: View {
    @EnvironmentObject var viewModel: HomeViewModel

    @State private var selectedLevel: Int?
    @State private var showAlert = false

    @State private var showLesson = false
    @State private var showGame = false
    @State private var showReuseGame = false
    @State private var showIdea = false

    var body: some View {

        NavigationStack {

            ScrollView {
                VStack(spacing: 0) {
                    ForEach(
                        Array(viewModel.categories.enumerated()),
                        id: \.element.id
                    ) { index, category in
                        VStack(spacing: 0) {

                            CategoryHeader(
                                category: category,
                                isTop: index == 0
                            )

                            ZStack(alignment: .bottomLeading) {

                                if index == 0 {
                                    Image(category.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 200)
                                        .padding(.leading, -20)
                                        .offset(y: -30)
                                } else if index == 1 {
                                    Image(category.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 250)
                                        .padding(.leading, 40)
                                        .offset(y: -30)
                                } else {
                                    Image(category.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 220)
                                        .padding(.leading, 40)
                                        .offset(y: -30)
                                }

                                LazyVStack(alignment: .trailing, spacing: 40) {
                                    ForEach(category.levels) { level in

                                        Button(action: {
                                            if level.status != .locked {

                                                if level.status == .current {

                                                    if level.type == "Lesson" {
                                                        showLesson = true
                                                    } else if level.type
                                                        == "Game"
                                                    {
                                                        showGame = true
                                                    } else if level.type
                                                        == "Idea"
                                                    {
                                                        showIdea = true
                                                    }

                                                } else {
                                                    selectedLevel = level.number
                                                    showAlert = true
                                                }
                                            }
                                        }) { EmptyView() }
                                        .buttonStyle(
                                            GameButtonStyle(
                                                color: category.color,
                                                status: level.status
                                            )
                                        )
                                        .frame(height: 90)
                                    }
                                }
                                .padding(.vertical, 40)
                                .padding(.trailing, 40)
                                .frame(
                                    maxWidth: .infinity,
                                    alignment: .trailing
                                )
                            }
                        }
                    }
                    Spacer().frame(height: 120)
                }
            }
            .edgesIgnoringSafeArea(.top)
            .background(Color.white)
            .alert("Level \(selectedLevel ?? 0)", isPresented: $showAlert) {
                Button("Ok", role: .cancel) {}
            } message: {
                Text("Level completed! Good job.")
            }

            .navigationDestination(isPresented: $showGame) {
                MainGameView()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $showReuseGame) {
                ReuseGameView()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $showLesson) {
                MainLessonView()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $showIdea) {
                UpcyclingIdeaView()
                    .navigationBarBackButtonHidden(true)
            }

            .onAppear {
                viewModel.refreshLevelsStatus()
            }
        }
    }
}

#Preview {
    HomeView()
        .environmentObject(HomeViewModel())
}
